export class Book {
  title: string;
  author: string;
  publishdate: number;
  category: string;
  coversrc: string;
  contact: string;
  phone: string;
  email: string;
}
